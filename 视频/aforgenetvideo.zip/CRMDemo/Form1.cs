﻿/*
 * by huiyaosoft.com
 * created at 2015-4-11
 * 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Imaging;
using System.Text;
using System.Windows;
using System.Windows.Forms;
using System.IO;
using AForge;
using AForge.Controls;
using AForge.Video;
using AForge.Video.DirectShow;
using Size = System.Drawing.Size;
using CRMDemo;

namespace CRMDemo
{

    public partial class Form1 : Form
    {
        private FilterInfoCollection videoDevices;

        VideoWork wv;
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
           try
            {
                // 枚举所有视频输入设备
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices.Count == 0)
                    throw new ApplicationException();

                foreach (FilterInfo device in videoDevices)
                {
                    cbCameras.Items.Add(device.Name);
                }

                cbCameras.SelectedIndex = 0;

            }
            catch (ApplicationException)
            {
                cbCameras.Items.Add("No local capture devices");
                videoDevices = null;
            }
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            if (wv == null)
            {
                wv = new VideoWork(this.panel1.Handle, 0, 0, this.panel1.Width, panel1.Height);
                wv.Start();
            }
            else
                this.button1.Enabled = false;
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
         string path=@"c:\demo.bmp";
            wv.GrabImage(path);
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            if (button3.Text == "录像")
            {
                string path = @"c:\demo.avi";
                wv.Kinescope(path);
                button3.Text = "停止";
            }
            else
            {
                button3.Text = "录像";
                wv.StopKinescope();
            }
        }

    }
}
